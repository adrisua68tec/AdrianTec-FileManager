# Cómo obtener la APK de AdrianTec (paso a paso)

1. Entrá a https://github.com con tu cuenta y abrí tu repositorio (o creá uno nuevo, privado si preferís).
2. Tocá **Add file → Upload files** y arrastrá TODO el contenido de esta carpeta
   (la carpeta `.github`, la carpeta `AdrianTec_FileManager_Android`, `.gitignore`).
   Importante: la carpeta oculta `.github` tiene que subirse también.
3. Tocá **Commit changes**.
4. Abrí la pestaña **Actions**. Verás "Compilar APK AdrianTec" ejecutándose (tarda ~5-8 min la primera vez).
   Si no arranca sola: elegí el flujo a la izquierda y tocá **Run workflow**.
5. Cuando aparezca el tilde verde, entrá a esa ejecución y abajo, en **Artifacts**, descargá `AdrianTec-FileManager-APK`.
6. Descomprimí el ZIP: adentro está `app-debug.apk`. Pasalo al teléfono e instalalo
   (Android te pedirá permitir "instalar apps desconocidas" para el explorador o navegador que uses).

Si aparece una cruz roja: copiame el texto del error (botón del paso que falló) y lo corregimos.
