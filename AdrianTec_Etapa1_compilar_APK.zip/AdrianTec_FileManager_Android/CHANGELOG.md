# Cambios

## 1.3.0
- Se agregó selección múltiple con selección por toque prolongado.
- Se agregaron acciones de copiado y eliminación por lote.
- El portapapeles admite varios elementos y conserva los que no pudieron moverse.

## 1.2.0
- Se agregaron filtros rápidos para imágenes, videos, audio, documentos y APK.
- Se corrigió la superposición repetida de wallpapers al cambiar la imagen.
- Se mejoró el manejo del portapapeles para no perder la selección cuando una copia o un movimiento falla.
- Se corrigió la copia recursiva para informar si algún elemento interno no pudo copiarse.
- Se valida el permiso persistente del selector de carpetas al restaurar la sesión.
- Se informa al usuario cuando Android no permite conservar permisos SAF.
- Se mantiene el proyecto sin permisos de Internet ni SDKs de publicidad/analítica.

## 1.1.0
- Primera base nativa Kotlin con selector SAF, exploración, búsqueda, operaciones básicas y wallpaper.
