# AdrianTec File Manager — base nativa 1.3.0 (Wallpaper / Green)

Primera etapa funcional de la reconstrucción nativa. Proyecto Kotlin para Android, con interfaz propia y sin SDKs de publicidad, analítica ni rastreo.

## Incluido en esta etapa
- Interfaz oscura con acento verde y paneles translúcidos.
- Selección de wallpaper desde imágenes del dispositivo (Photo Picker/document provider).
- Selección de carpeta mediante Storage Access Framework (SAF), con permiso persistente.
- Exploración de carpetas y subcarpetas dentro del árbol autorizado.
- Búsqueda por nombre.
- Filtros por imágenes, videos, audio, documentos y APK.
- Selección múltiple con copiado y eliminación por lote.
- Apertura de archivos con aplicaciones compatibles.
- Información, copiar, cortar/mover, pegar, renombrar y eliminar.
- Sin permisos de Internet, publicidad, identificadores publicitarios ni SDKs de analítica.

## Compilar
Abrir esta carpeta en Android Studio, instalar Android SDK 35 y sincronizar Gradle. Ejecutar en un dispositivo Android 8.0 o superior; objetivo principal de prueba: Android 13.

## Privacidad y límites
El acceso al almacenamiento se limita a la carpeta que el usuario autoriza con el selector oficial de Android. No se solicita `MANAGE_EXTERNAL_STORAGE`. Android y algunos proveedores restringen ubicaciones como `Android/data` y `Android/obb`. Las operaciones dependen de las capacidades del proveedor SAF. La opción cortar/mover copia primero y luego intenta borrar el origen; si Android no permite borrarlo, el original se conserva.

## Pendiente para siguientes etapas
Miniaturas y visores integrados, ZIP/RAR, administrador de APK, análisis de almacenamiento, soporte de tarjetas SD y pruebas en distintos fabricantes. Esta entrega es código fuente; todavía no es un APK compilado ni validado en dispositivo.
