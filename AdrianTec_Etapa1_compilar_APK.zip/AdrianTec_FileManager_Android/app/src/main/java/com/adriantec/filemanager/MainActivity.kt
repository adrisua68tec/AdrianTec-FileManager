package com.adriantec.filemanager

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.text.DateFormat
import java.text.DecimalFormat
import java.util.Date

class MainActivity : Activity() {
    companion object {
        private const val REQ_TREE = 1001
        private const val REQ_WALLPAPER = 1002
        private const val PREFS = "adriantec_preferences"
        private const val KEY_TREE = "tree_uri"
        private const val KEY_WALLPAPER = "wallpaper_uri"
        private const val GREEN = 0xFF39E66B.toInt()
        private const val DARK = 0xDD07110B.toInt()
    }

    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var pathLabel: TextView
    private lateinit var search: EditText
    private lateinit var list: LinearLayout
    private var rootFolder: DocumentFile? = null
    private var currentFolder: DocumentFile? = null
    private val selectedFiles = linkedMapOf<String, DocumentFile>()
    private var selectionMode = false
    private var clipboard = mutableListOf<DocumentFile>()
    private var cutMode = false
    private var activeFilter = "TODOS"
    private var wallpaperView: ImageView? = null
    private var wallpaperShade: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreWallpaper()
        restoreTree()
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5, 12, 8)) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply {
            text = "ADRIANTEC"
            textSize = 24f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(GREEN)
        }
        val subtitle = TextView(this).apply {
            text = "FILE MANAGER  •  EXPLORADOR DE ARCHIVOS"
            textSize = 10f
            letterSpacing = .13f
            setTextColor(0xFFE2F5E7.toInt())
        }
        header.addView(brand)
        header.addView(subtitle)
        content.addView(header)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(8))
        }
        actions.addView(actionButton("ALMACENAMIENTO") { chooseStorage() }, weightParams())
        actions.addView(actionButton("WALLPAPER") { chooseWallpaper() }, weightParams())
        content.addView(actions)

        pathLabel = TextView(this).apply {
            text = "Sin carpeta seleccionada"
            textSize = 12f
            setTextColor(GREEN)
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = panelBackground()
        }
        content.addView(pathLabel)

        search = EditText(this).apply {
            hint = "Buscar archivos y carpetas…"
            setHintTextColor(0xFF9BB4A1.toInt())
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            background = panelBackground()
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(9) }
        content.addView(search, searchParams)
        search.addTextChangedListener(SimpleTextWatcher { renderFiles() })

        val categoryScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(8), 0, dp(2))
        }
        val categories = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("TODOS", "IMÁGENES", "VIDEOS", "AUDIO", "DOCUMENTOS", "APK").forEach { category ->
            val chip = actionButton(category) {
                activeFilter = category
                renderFiles()
            }
            categories.addView(chip, LinearLayout.LayoutParams(-2, dp(38)).apply { marginEnd = dp(6) })
        }
        categoryScroll.addView(categories)
        content.addView(categoryScroll)

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        tools.addView(actionButton("ATRÁS") { goUp() }, weightParams())
        tools.addView(actionButton("PEGAR") { paste() }, weightParams())
        tools.addView(actionButton("SELECCIÓN") { toggleSelectionMode() }, weightParams())
        tools.addView(actionButton("ACTUALIZAR") { renderFiles() }, weightParams())
        content.addView(tools)

        val selectionTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        selectionTools.tag = "selection_tools"
        selectionTools.addView(actionButton("COPIAR SEL.") {
            if (selectedFiles.isNotEmpty()) {
                clipboard = selectedFiles.values.toMutableList()
                cutMode = false
                exitSelectionMode()
                showMessage("${clipboard.size} elemento(s) preparados para copiar. Elegí destino y tocá PEGAR.")
            }
        }, weightParams())
        selectionTools.addView(actionButton("ELIMINAR SEL.") { confirmDeleteSelected() }, weightParams())
        selectionTools.addView(actionButton("CANCELAR") { exitSelectionMode() }, weightParams())
        content.addView(selectionTools)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            background = panelBackground()
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        scroll.addView(list)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "PRIVACIDAD PRIMERO  •  SIN PUBLICIDAD NI RASTREADORES"
            textSize = 9f
            letterSpacing = .06f
            gravity = Gravity.CENTER
            setTextColor(0xFFB4D4BC.toInt())
            setPadding(0, dp(10), 0, 0)
        }
        content.addView(footer)
        setContentView(root)
    }

    private fun restoreTree() {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TREE, null) ?: return
        runCatching {
            val uri = Uri.parse(raw)
            val stillGranted = contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
            if (!stillGranted) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TREE).apply()
                showMessage("Android ya no conserva el permiso. Volvé a elegir la carpeta.")
                return
            }
            rootFolder = DocumentFile.fromTreeUri(this, uri)
            currentFolder = rootFolder
            renderFiles()
        }.onFailure {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TREE).apply()
            showMessage("Volvé a seleccionar la carpeta: el permiso ya no está disponible.")
        }
    }

    private fun chooseStorage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_TREE)
    }

    private fun chooseWallpaper() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_WALLPAPER)
    }

    @Deprecated("Using activity result callbacks for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_TREE -> {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                val persisted = runCatching {
                    if (flags == 0) false else {
                        contentResolver.takePersistableUriPermission(uri, flags)
                        true
                    }
                }.getOrDefault(false)
                if (persisted) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TREE, uri.toString()).apply()
                } else {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TREE).apply()
                    showMessage("La carpeta se abrirá ahora, pero Android no permitió conservar el permiso. Si cerrás la app, tendrás que seleccionarla otra vez.")
                }
                rootFolder = DocumentFile.fromTreeUri(this, uri)
                currentFolder = rootFolder
                renderFiles()
            }
            REQ_WALLPAPER -> {
                val flags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
                val persisted = runCatching {
                    if (flags == 0) false else {
                        contentResolver.takePersistableUriPermission(uri, flags)
                        true
                    }
                }.getOrDefault(false)
                if (persisted) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_WALLPAPER, uri.toString()).apply()
                } else {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_WALLPAPER).apply()
                    showMessage("La imagen se aplicó, pero Android no permitió conservar el acceso. Podrás elegirla otra vez después.")
                }
                applyWallpaper(uri)
            }
        }
    }

    private fun restoreWallpaper() {
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_WALLPAPER, null)?.let {
            runCatching { applyWallpaper(Uri.parse(it)) }
        }
    }

    private fun applyWallpaper(uri: Uri) {
        wallpaperView?.let { root.removeView(it) }
        wallpaperShade?.let { root.removeView(it) }
        val image = ImageView(this).apply {
            setImageURI(uri)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = .34f
        }
        val shade = View(this).apply { setBackgroundColor(0xAA030A05.toInt()) }
        wallpaperView = image
        wallpaperShade = shade
        root.addView(image, 0, FrameLayout.LayoutParams(-1, -1))
        root.addView(shade, 1, FrameLayout.LayoutParams(-1, -1))
        content.bringToFront()
    }

    private fun renderFiles() {
        list.removeAllViews()
        val folder = currentFolder
        if (folder == null) {
            addEmpty("Elegí una carpeta para comenzar a explorar.")
            pathLabel.text = "Sin carpeta seleccionada"
            return
        }
        val folderTitle = folder.name ?: "Almacenamiento autorizado"
        pathLabel.text = if (selectionMode) "$folderTitle  •  ${selectedFiles.size} seleccionado(s)" else folderTitle
        val query = search.text?.toString()?.trim()?.lowercase().orEmpty()
        val files = runCatching { folder.listFiles().toList() }.getOrElse {
            addEmpty("No se pudo leer esta carpeta. Revisá los permisos concedidos.")
            return
        }.filter { query.isEmpty() || (it.name ?: "").lowercase().contains(query) }
            .filter { matchesCategory(it, activeFilter) }
            .sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { (it.name ?: "").lowercase() })

        if (files.isEmpty()) {
            addEmpty(if (query.isEmpty() && activeFilter == "TODOS") "Esta carpeta está vacía." else "No hay coincidencias para este filtro.")
            return
        }
        files.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(8), dp(10))
                background = ColorDrawable(0x55203327)
            }
            val icon = TextView(this).apply {
                text = when { file.isDirectory -> "▰"; file.type?.startsWith("image/") == true -> "▧"; file.type?.startsWith("video/") == true -> "▶"; file.type?.contains("pdf") == true -> "▤"; else -> "▱" }
                textSize = 20f
                setTextColor(GREEN)
                gravity = Gravity.CENTER
                width = dp(34)
            }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val name = TextView(this).apply {
                text = file.name ?: "Sin nombre"
                textSize = 14f
                setTextColor(Color.WHITE)
                maxLines = 1
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val detail = TextView(this).apply {
                text = if (file.isDirectory) "CARPETA" else "${formatSize(file.length())}  •  ${file.type ?: "archivo"}"
                textSize = 10f
                setTextColor(0xFFB5C9BA.toInt())
            }
            labels.addView(name); labels.addView(detail)
            row.addView(icon)
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val more = TextView(this).apply {
                text = "⋮"
                textSize = 24f
                setTextColor(GREEN)
                gravity = Gravity.CENTER
                setPadding(dp(12), 0, dp(4), 0)
                setOnClickListener { showFileActions(file) }
            }
            row.addView(more)
            val selectedNow = selectedFiles.containsKey(file.uri.toString())
            if (selectionMode && selectedNow) row.setBackgroundColor(0xAA1D6534.toInt())
            if (selectionMode) {
                icon.text = if (selectedNow) "✓" else "○"
            }
            row.setOnClickListener {
                if (selectionMode) toggleSelectedFile(file)
                else if (file.isDirectory) { currentFolder = file; search.setText(""); renderFiles() }
                else openFile(file)
            }
            row.setOnLongClickListener {
                if (!selectionMode) toggleSelectionMode()
                toggleSelectedFile(file)
                true
            }
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) }
            list.addView(row, lp)
        }
    }

    private fun matchesCategory(file: DocumentFile, category: String): Boolean {
        if (category == "TODOS") return true
        if (file.isDirectory) return false
        val name = (file.name ?: "").lowercase()
        val mime = (file.type ?: "").lowercase()
        return when (category) {
            "IMÁGENES" -> mime.startsWith("image/") || name.endsWithAny(".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".bmp")
            "VIDEOS" -> mime.startsWith("video/") || name.endsWithAny(".mp4", ".mkv", ".mov", ".avi", ".webm", ".3gp")
            "AUDIO" -> mime.startsWith("audio/") || name.endsWithAny(".mp3", ".wav", ".ogg", ".m4a", ".flac", ".aac")
            "DOCUMENTOS" -> mime.startsWith("text/") || mime.contains("pdf") || mime.contains("officedocument") || name.endsWithAny(".pdf", ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".rtf", ".odt")
            "APK" -> name.endsWith(".apk") || mime == "application/vnd.android.package-archive"
            else -> true
        }
    }

    private fun String.endsWithAny(vararg suffixes: String): Boolean = suffixes.any { endsWith(it) }

    private fun toggleSelectionMode() {
        selectionMode = !selectionMode
        if (!selectionMode) selectedFiles.clear()
        content.findViewWithTag<LinearLayout>("selection_tools")?.visibility = if (selectionMode) View.VISIBLE else View.GONE
        renderFiles()
    }

    private fun exitSelectionMode() {
        selectionMode = false
        selectedFiles.clear()
        content.findViewWithTag<LinearLayout>("selection_tools")?.visibility = View.GONE
        renderFiles()
    }

    private fun toggleSelectedFile(file: DocumentFile) {
        val key = file.uri.toString()
        if (selectedFiles.containsKey(key)) selectedFiles.remove(key) else selectedFiles[key] = file
        pathLabel.text = "${currentFolder?.name ?: "Almacenamiento"}  •  ${selectedFiles.size} seleccionado(s)"
        renderFiles()
    }

    private fun confirmDeleteSelected() {
        if (selectedFiles.isEmpty()) {
            showMessage("No hay elementos seleccionados.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Eliminar ${selectedFiles.size} elemento(s)")
            .setMessage("Esta acción no se puede deshacer. ¿Continuar?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Eliminar") { _, _ ->
                val total = selectedFiles.size
                var deleted = 0
                selectedFiles.values.toList().forEach { if (it.delete()) deleted++ }
                exitSelectionMode()
                showMessage("Eliminados: $deleted. No se pudieron eliminar: ${total - deleted}.")
            }.show()
    }

    private fun showFileActions(file: DocumentFile) {
        val actions = arrayOf("Información", "Copiar", "Cortar / mover", "Renombrar", "Eliminar", "Abrir")
        AlertDialog.Builder(this).setTitle(file.name ?: "Archivo").setItems(actions) { _, which ->
            when (which) {
                0 -> showInfo(file)
                1 -> { clipboard = mutableListOf(file); cutMode = false; showMessage("Copiado al portapapeles interno de la app.") }
                2 -> { clipboard = mutableListOf(file); cutMode = true; showMessage("Seleccioná la carpeta de destino y tocá PEGAR.") }
                3 -> rename(file)
                4 -> confirmDelete(file)
                5 -> openFile(file)
            }
        }.show()
    }

    private fun paste() {
        if (clipboard.isEmpty()) { showMessage("No hay ningún archivo copiado o cortado."); return }
        val destination = currentFolder ?: run { showMessage("Elegí primero una carpeta de destino."); return }
        if (!destination.canWrite()) { showMessage("El proveedor no permite escribir en esta carpeta."); return }
        if (clipboard.any { source -> source.uri == destination.uri || destination.uri.toString().startsWith(source.uri.toString()) }) {
            showMessage("No se puede copiar una carpeta dentro de sí misma."); return
        }
        var copied = 0
        var deleteFailed = 0
        val pending = mutableListOf<DocumentFile>()
        clipboard.toList().forEach { source ->
            if (copyDocument(source, destination)) {
                copied++
                if (cutMode && !source.delete()) deleteFailed++
            } else {
                pending.add(source)
            }
        }
        clipboard = pending
        if (clipboard.isEmpty()) {
            if (cutMode) {
                showMessage("Movimiento: $copied elemento(s) copiados; $deleteFailed original(es) no se pudieron borrar y se conservan.")
            } else {
                showMessage("Copia completada: $copied elemento(s).")
            }
            cutMode = false
        } else {
            showMessage("Se copiaron $copied elemento(s). ${clipboard.size} quedaron pendientes y siguen en el portapapeles.")
        }
        renderFiles()
    }

    private fun copyDocument(source: DocumentFile, destination: DocumentFile): Boolean {
        return try {
            if (source.isDirectory) {
                val dir = destination.createDirectory(source.name ?: "Carpeta") ?: return false
                var allCopied = true
                source.listFiles().forEach { child ->
                    if (!copyDocument(child, dir)) allCopied = false
                }
                allCopied
            } else {
                val target = destination.createFile(source.type ?: "application/octet-stream", source.name ?: "archivo") ?: return false
                contentResolver.openInputStream(source.uri).use { input ->
                    contentResolver.openOutputStream(target.uri, "w").use { output ->
                        if (input == null || output == null) return false
                        input.copyTo(output)
                    }
                }
                true
            }
        } catch (_: Exception) { false }
    }

    private fun rename(file: DocumentFile) {
        val input = EditText(this).apply { setText(file.name ?: ""); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Renombrar").setView(input)
            .setNegativeButton("Cancelar", null).setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotBlank() && file.renameTo(newName)) renderFiles() else showMessage("No se pudo renombrar el elemento.")
            }.show()
    }

    private fun confirmDelete(file: DocumentFile) {
        AlertDialog.Builder(this).setTitle("Eliminar elemento")
            .setMessage("¿Querés eliminar ${file.name}?")
            .setNegativeButton("Cancelar", null).setPositiveButton("Eliminar") { _, _ ->
                if (file.delete()) renderFiles() else showMessage("Android o el proveedor no permitió eliminarlo.")
            }.show()
    }

    private fun showInfo(file: DocumentFile) {
        val modified = if (file.lastModified() > 0) DateFormat.getDateTimeInstance().format(Date(file.lastModified())) else "No disponible"
        AlertDialog.Builder(this).setTitle("Información")
            .setMessage("Nombre: ${file.name}\nTipo: ${file.type ?: if (file.isDirectory) "Carpeta" else "Desconocido"}\nTamaño: ${formatSize(file.length())}\nModificado: $modified\nUbicación: ${file.uri}")
            .setPositiveButton("Cerrar", null).show()
    }

    private fun openFile(file: DocumentFile) {
        try {
            val mime = file.type ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(file.uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Abrir con"))
        } catch (_: Exception) { showMessage("No hay una aplicación compatible para abrir este archivo.") }
    }

    private fun goUp() {
        val current = currentFolder ?: return
        val parent = current.parentFile
        if (parent != null && (current.uri != rootFolder?.uri)) {
            currentFolder = parent
            search.setText("")
            renderFiles()
        } else showMessage("Ya estás en la carpeta inicial autorizada.")
    }

    private fun showMessage(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun addEmpty(message: String) {
        list.addView(TextView(this).apply {
            text = message
            textSize = 13f
            setTextColor(0xFFD3E4D7.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(36), dp(18), dp(36))
        })
    }
    private fun actionButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 10f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-bold", Typeface.BOLD)
        setTextColor(GREEN)
        setPadding(dp(8), dp(11), dp(8), dp(11))
        background = panelBackground()
        setOnClickListener { action() }
    }
    private fun panelBackground() = android.graphics.drawable.GradientDrawable().apply {
        setColor(DARK)
        setStroke(dp(1), 0x8839E66B.toInt())
        cornerRadius = dp(12).toFloat()
    }
    private fun weightParams() = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var size = bytes.toDouble(); var unit = 0
        while (size >= 1024 && unit < units.lastIndex) { size /= 1024; unit++ }
        return "${DecimalFormat("0.##").format(size)} ${units[unit]}"
    }
}
