package com.adriantec.filemanager

import android.text.Editable
import android.text.TextWatcher

class SimpleTextWatcher(private val changed: () -> Unit) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = changed()
    override fun afterTextChanged(s: Editable?) = Unit
}
